## setRadioVolume

## Description

Sets the local players radio channel volume

## Parameters

* **radioVolume**: the radio volume to set to between 0 - 100 percent

```lua
-- sets the radio volume to 50 percent
exports['pma-voice']:setRadioVolume(50)
```